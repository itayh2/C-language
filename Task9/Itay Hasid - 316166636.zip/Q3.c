#include <stdio.h>
#include <string.h>
#define SIZE 30
void removeSpaces(char *str1);
int main()
{
    char str[SIZE];
    printf("Please insert a sentence up to %d letters: ", SIZE - 1);
    gets(str);
    removeSpaces(str);
    puts(str);
}
void removeSpaces(char *str1)
{
    char *p1 = str1;
    char *p2;
    while (*p1 != '\0')
    {
        if(*p1 == ' ')
        {
            p2 = p1;
            while (*p2 != '\0')
            {
                *p2 = *(p2 + 1);
                p2++;
            }
        }
        p1++;
    }
}

