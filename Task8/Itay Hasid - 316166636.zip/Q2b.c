#define SIZE 30
#include <stdio.h>
#include <string.h>
void right_Trim(char str[]);
int main()
{
    char str[SIZE];
    printf("Please insert a string up to %d words: \n", SIZE - 1);
    gets(str);
    right_Trim(str);
    printf("%s\n", str);
}
void right_Trim(char str[])
{
    int countOfTav = strlen(str);
    int i = 0;
    while (str[i] == ' ')
    {
        i++;
    }
    for (int j = 0; j < countOfTav; j++)
    {
        str[j] = str[i];
        i++;
    }
}
