#include <stdio.h>
int main()
{
    int counter1 = 0, counter2 = 0, counter3 = 0, counter4 = 0;
    char tav = 0;
    printf("Please insert characteers. To finish press Q\n");
    while (tav != 'Q')
    {
    scanf(" %c", &tav);
    switch (tav)
    {
        case '/':
            counter1++;
            break;
        case '*':
            counter2++;
            break;
        case '-':
            counter3++;
            break;
        case '+':
            counter4++;
            break;
        default:
            break;
    }
    }
    printf("/ appears %d times\n", counter1);
    printf("* appears %d times\n", counter2);
    printf("- apperas %d times\n", counter3);
    printf("+ appears %d times\n", counter4);
}
