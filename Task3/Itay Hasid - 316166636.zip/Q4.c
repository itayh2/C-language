#include <stdio.h>
#include <math.h>
int main()
{
    int a, b, c;
    double Discriminant = 0;
    printf("Enter a 3 numbers:\n");
    scanf("%d %d %d", &a, &b, &c);
    Discriminant = pow(b, 2)-(4*a*c);
    if (Discriminant > 0)
    {
        printf("x1 = %.2f\n",((double)-b + sqrt(Discriminant)) / (2 * a));
        printf("x2 = %.2f\n",((double)-b - sqrt(Discriminant)) / (2 * a));
    }
        else if (Discriminant == 0)
        {
            printf("x = %.2f\n", (double)-b / 2 * a);
        }
    else
{
        printf("No have solution\n");
}
}