#include <stdio.h>
int main()
{
    int number, hundreds, units;
    printf("Enter a number of 3 digits:\n");
    scanf("%d", &number);
    hundreds = number / 100;
    units = number % 10;
    if (number > 99 &&  number < 1000)
    {
        if(number % 7 == 0)
    {
        printf("%d Seven boom!\n", number);
    if(hundreds == units)
    {
        printf("%d Is palindrom\n", number);
    }
    }
    else
    {
        printf("%.2f\n", (double)number / 7);
    }
    }
    else
    printf("illegal number entered\n");
}